import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Video, Eye } from 'lucide-react';
import { BackgroundTexture } from './components/BackgroundTexture';
import { RosePetals } from './components/RosePetals';
import { AudioPlayer } from './components/AudioPlayer';
import { VideoHeroPlayer } from './components/VideoHeroPlayer';
import WeddingTeklilInvitation from './components/WeddingTeklilInvitation';
import { SceneScratchReveal } from './components/SceneScratchReveal';
import { DateReveal } from './components/DateReveal';
import { SceneCountdown } from './components/SceneCountdown';
import { EventDetailsSection } from './components/EventDetailsSection';
import { LocationSection } from './components/LocationSection';
import { FinalBlessing } from './components/FinalBlessing';

export default function App() {
  const [isRevealed, setIsRevealed] = useState(false);
  const [showVideoCompare, setShowVideoCompare] = useState(false);
  const mainContentRef = useRef<HTMLDivElement | null>(null);

  const handleDateRevealed = () => {
    setIsRevealed(true);
  };

  const handleReplay = () => {
    setIsRevealed(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-screen text-[#4d1015] bg-[#120e0b] font-sans selection:bg-[#7a1b22]/20 selection:text-[#7a1b22]">
      {/* Background Atmosphere Texture */}
      <BackgroundTexture />

      {/* Floating Rose Petals Animation */}
      <RosePetals />

      {/* Floating Audio Controller */}
      <AudioPlayer shouldPlay={true} audioUrl="/invitation-audio.mp3" />

      {/* Main Container */}
      <div className="relative z-10 min-h-screen flex flex-col items-center py-6">
        <motion.main
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-3xl mx-auto px-4 flex flex-col items-center gap-10 md:gap-14"
          ref={mainContentRef}
        >
          {/* Header Title & Theme Badge */}
          <div className="text-center pt-2 select-none">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8B2635]/20 border border-[#C59B27]/40 text-[#F5EADB] text-xs font-serif tracking-widest uppercase mb-2">
              <Sparkles size={13} className="text-[#C59B27]" />
              <span>ሥርዓተ ተክሊል • Holy Matrimony</span>
            </div>
            <h1 className="font-serif text-3xl md:text-5xl font-bold text-[#F5EADB] tracking-wide drop-shadow-md">
              Yohannes & Selamawit
            </h1>
            <p className="font-serif text-xs md:text-sm text-[#C59B27] italic mt-1">
              እሑድ ኅዳር ፲፫ ቀን ፪ሺ፲፱ ዓ.ም. • Sunday, November 22, 2026
            </p>
          </div>

          {/* 1. 3D Gatefold Teklil Invitation Card (Primary Experience from Video 2 & 1) */}
          <section className="w-full flex flex-col items-center justify-center">
            <WeddingTeklilInvitation />

            {/* Video Inspiration Comparison Toggle */}
            <div className="mt-4 flex items-center justify-center">
              <button
                onClick={() => setShowVideoCompare(!showVideoCompare)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-white/90 text-xs font-sans font-medium transition-all backdrop-blur-sm cursor-pointer shadow-sm"
              >
                <Video size={14} className="text-[#C59B27]" />
                <span>{showVideoCompare ? "Hide Video Comparison" : "🎬 Compare with Original Video Clip"}</span>
              </button>
            </div>

            {/* Collapsible Video Comparison Player */}
            {showVideoCompare && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.5 }}
                className="w-full max-w-sm mt-4 flex flex-col items-center"
              >
                <VideoHeroPlayer videoUrl="/invitation-video.mp4" />
              </motion.div>
            )}
          </section>

          {/* 2. Date Reveal Scratch Card */}
          <section className="w-full">
            <SceneScratchReveal
              onRevealed={handleDateRevealed}
              isRevealed={isRevealed}
            />
          </section>

          {/* Revealed Date Payoff */}
          {isRevealed && (
            <section className="w-full">
              <DateReveal />
            </section>
          )}

          {/* 3. Live Countdown */}
          <section className="w-full border-t border-[#7a1b22]/20 pt-10">
            <SceneCountdown />
          </section>

          {/* 4. Event Details (Ceremony & Reception) */}
          <section className="w-full">
            <EventDetailsSection />
          </section>

          {/* 5. Location & Directions */}
          <section className="w-full">
            <LocationSection />
          </section>

          {/* 6. Final Blessing & Replay */}
          <section className="w-full border-t border-[#7a1b22]/20 pt-10 pb-16">
            <FinalBlessing onReplay={handleReplay} />
          </section>
        </motion.main>
      </div>
    </div>
  );
}
