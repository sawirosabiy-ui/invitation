export interface InvitationData {
  eventType: string;
  title: string;
  subtitle: string;
  names: string;
  trinityBlessing: string;
  trinityEnglish: string;
  geezOccasion: string;
  audioUrl: string;
  groom: {
    name: string;
    family: string;
  };
  bride: {
    name: string;
    family: string;
  };
  mainInvitationText: {
    familyHeader: string;
    romanticLine: string;
  };
  date: {
    formatted: string;
    dayOfWeek: string;
    day: string;
    month: string;
    year: string;
  };
  eventDateTime: string; // ISO 8601 string for real-time countdown
  time: string;
  ceremony: {
    title: string;
    date: string;
    time: string;
    venue: string;
    address: string;
  };
  reception: {
    title: string;
    date: string;
    time: string;
    venue: string;
    address: string;
  };
  location: {
    name: string;
    address: string;
    mapUrl: string;
  };
  memoryStory: {
    quote: string;
    storyParagraph: string;
    memories: Array<{
      caption: string;
      image: string;
    }>;
  };
  openingText: string;
  openingMessage: string;
  blessingHeader: string;
  message: string;
  invitationMessage: string;
  closingMessage: string;
}

export const invitationData: InvitationData = {
  eventType: "Holy Matrimony",
  title: "ሥርዓተ ተክሊል",
  subtitle: "Holy Matrimony & Wedding Celebration",
  names: "Yohannes & Selamawit",
  trinityBlessing: "በስመ አብ ወወልድ ወመንፈስ ቅዱስ አሐዱ አምላክ አሜን",
  trinityEnglish: "In the name of the Father, & and of the Son, and of the Holy Spirit",
  geezOccasion: "ሥርዓተ ተክሊል • Holy Matrimony",
  audioUrl: "/invitation-audio.mp3",
  groom: {
    name: "Yohannes Tesfaye",
    family: "Son of Mr. & Mrs. Tesfaye",
  },
  bride: {
    name: "Selamawit Daniel",
    family: "Daughter of Mr. & Mrs. Daniel",
  },
  mainInvitationText: {
    familyHeader: "Together with their families",
    romanticLine: "A beautiful chapter of our lives about to begin, and we would be honored to have you with us.",
  },
  date: {
    formatted: "Sunday, November 22, 2026",
    dayOfWeek: "SUNDAY",
    day: "22",
    month: "NOVEMBER",
    year: "2026",
  },
  eventDateTime: "2026-11-22T10:30:00+03:00",
  time: "10:30 AM (Morning)",
  ceremony: {
    title: "Church Crowning (ሥርዓተ ተክሊል)",
    date: "Sunday, November 22, 2026",
    time: "10:30 AM",
    venue: "Bole Medhane Alem Cathedral",
    address: "Bole, Addis Ababa, Ethiopia",
  },
  reception: {
    title: "Dinner Reception (የሠርግ ምሽት ግብዣ)",
    date: "Sunday, November 22, 2026",
    time: "06:00 PM",
    venue: "Skylight Grand Ballroom",
    address: "Ethiopian Skylight Hotel, Addis Ababa, Ethiopia",
  },
  location: {
    name: "Skylight Grand Ballroom & Bole Medhane Alem",
    address: "Addis Ababa, Ethiopia",
    mapUrl: "https://maps.google.com/?q=Ethiopian+Skylight+Hotel+Addis+Ababa",
  },
  memoryStory: {
    quote: "A beautiful chapter of our lives, woven with love and family blessings.",
    storyParagraph: "From our first meeting to this sacred union under God's grace, we cherish every step of our journey together.",
    memories: [
      {
        caption: "The Journey Begins",
        image: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=80",
      },
      {
        caption: "Blessings & Unity",
        image: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=800&q=80",
      }
    ]
  },
  openingText: "You have been invited",
  openingMessage: "You have been invited",
  blessingHeader: "With gratitude to God and the blessing of our families",
  message: "We warmly invite you to share in this special occasion with us as our families gather in unity, joy, and prayer.",
  invitationMessage: "We warmly invite you to share in this special occasion with us as our families gather in unity, joy, and prayer.",
  closingMessage: "With God's blessing, we look forward to sharing this special occasion with you.",
};
