import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Volume2, VolumeX, Maximize2 } from 'lucide-react';

interface VideoHeroPlayerProps {
  videoUrl?: string;
  onEnded?: () => void;
}

export const VideoHeroPlayer: React.FC<VideoHeroPlayerProps> = ({
  videoUrl = "/invitation-video.mp4",
  onEnded,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    video.play().then(() => {
      setIsPlaying(true);
    }).catch((err) => {
      console.log("Autoplay caught:", err);
      setIsPlaying(false);
    });
  }, []);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
      setIsPlaying(false);
    } else {
      video.play();
      setIsPlaying(true);
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleRestart = () => {
    const video = videoRef.current;
    if (!video) return;

    video.currentTime = 0;
    video.play();
    setIsPlaying(true);
  };

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;

    if (video.duration) {
      setProgress((video.currentTime / video.duration) * 100);
    }
  };

  const toggleFullScreen = () => {
    const video = videoRef.current;
    if (!video) return;

    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      video.requestFullscreen().catch(console.error);
    }
  };

  return (
    <div className="relative w-full max-w-md mx-auto rounded-3xl overflow-hidden shadow-2xl border-4 border-[#7a1b22]/40 bg-black group my-4">
      {/* Video Element */}
      <video
        ref={videoRef}
        src={videoUrl}
        playsInline
        autoPlay
        loop
        onTimeUpdate={handleTimeUpdate}
        onEnded={onEnded}
        className="w-full h-auto aspect-[9/16] object-cover cursor-pointer"
        onClick={togglePlay}
      />

      {/* Video Control Bar Overlay */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col gap-2 opacity-90 group-hover:opacity-100 transition-opacity">
        {/* Progress Line */}
        <div className="w-full h-1 bg-white/30 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#7a1b22] to-[#d4a325] transition-all duration-150"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-between text-white text-xs font-sans">
          <div className="flex items-center gap-3">
            <button
              onClick={togglePlay}
              className="p-1.5 rounded-full bg-white/20 hover:bg-white/40 transition-colors cursor-pointer"
              title={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? <Pause size={16} /> : <Play size={16} />}
            </button>

            <button
              onClick={handleRestart}
              className="p-1.5 rounded-full bg-white/20 hover:bg-white/40 transition-colors cursor-pointer"
              title="Restart Video"
            >
              <RotateCcw size={14} />
            </button>

            <button
              onClick={toggleMute}
              className="p-1.5 rounded-full bg-white/20 hover:bg-white/40 transition-colors cursor-pointer"
              title={isMuted ? "Unmute" : "Mute"}
            >
              {isMuted ? <VolumeX size={14} className="text-red-400" /> : <Volume2 size={14} />}
            </button>
          </div>

          <button
            onClick={toggleFullScreen}
            className="p-1.5 rounded-full bg-white/20 hover:bg-white/40 transition-colors cursor-pointer"
            title="Fullscreen"
          >
            <Maximize2 size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};
