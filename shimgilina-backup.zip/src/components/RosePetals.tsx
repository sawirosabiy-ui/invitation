import React, { useMemo } from 'react';

export const RosePetals: React.FC = () => {
  const petals = useMemo(() => {
    return Array.from({ length: 22 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      size: Math.random() * 16 + 10,
      duration: Math.random() * 8 + 6,
      delay: Math.random() * 8,
      rotation: Math.random() * 360,
    }));
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {petals.map((petal) => (
        <div
          key={petal.id}
          className="absolute opacity-80"
          style={{
            left: `${petal.left}%`,
            top: '-20px',
            animation: `petalFall ${petal.duration}s linear infinite`,
            animationDelay: `${petal.delay}s`,
          }}
        >
          {/* SVG Rose Petal Silhouette */}
          <svg
            width={petal.size}
            height={petal.size * 1.25}
            viewBox="0 0 30 36"
            fill="none"
            style={{ transform: `rotate(${petal.rotation}deg)` }}
          >
            <path
              d="M15 0 C25 8, 30 20, 20 32 C12 38, 2 30, 5 18 C8 8, 10 2, 15 0 Z"
              fill="url(#rosePetalGradient)"
              opacity="0.88"
            />
            <defs>
              <linearGradient id="rosePetalGradient" x1="0" y1="0" x2="30" y2="36" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#9e222d" />
                <stop offset="50%" stopColor="#7a1b22" />
                <stop offset="100%" stopColor="#4d1015" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      ))}
    </div>
  );
};
