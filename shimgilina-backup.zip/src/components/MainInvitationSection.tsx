import React from 'react';
import { motion } from 'framer-motion';
import { GoldenCrowns } from './GoldenCrowns';
import { OrthodoxCross } from './OrthodoxCross';
import { invitationData } from '../config/invitationData';

export const MainInvitationSection: React.FC = () => {
  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-8 text-center select-none">
      <motion.div
        initial={{ opacity: 0, y: 25 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="relative p-8 md:p-12 rounded-3xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-2xl shadow-[#7a1b22]/15 backdrop-blur-md overflow-hidden"
      >
        {/* Subtle Orthodox Cross Ornament */}
        <div className="flex justify-center mb-4">
          <div className="p-2.5 rounded-full bg-[#7a1b22]/10 border border-[#7a1b22]/20">
            <OrthodoxCross size={26} className="text-[#7a1b22]" />
          </div>
        </div>

        {/* Family Header */}
        <p className="font-serif italic text-sm md:text-base text-[#7a1b22] uppercase tracking-widest font-semibold mb-2">
          {invitationData.mainInvitationText.familyHeader}
        </p>

        {/* Twin Golden Crowns */}
        <GoldenCrowns className="my-2" />

        {/* Couple Names */}
        <div className="py-3 flex flex-col items-center gap-1">
          <h2 className="font-['Alex_Brush',_cursive] text-5xl md:text-7xl text-[#1b4d2e] tracking-wide">
            {invitationData.groom.name}
          </h2>
          <span className="font-serif italic text-2xl text-[#7a1b22] my-1">&amp;</span>
          <h2 className="font-['Alex_Brush',_cursive] text-5xl md:text-7xl text-[#1b4d2e] tracking-wide">
            {invitationData.bride.name}
          </h2>
        </div>

        {/* Parents Solicit Line */}
        <p className="font-sans text-xs tracking-widest uppercase text-[#7a1b22] font-semibold my-4">
          {invitationData.groom.family} • {invitationData.bride.family}
        </p>

        <div className="w-20 h-[1.5px] bg-[#7a1b22]/30 mx-auto my-4" />

        {/* Romantic Invitation Line */}
        <p className="font-serif italic text-base md:text-lg text-[#4d1015] leading-relaxed max-w-md mx-auto">
          "{invitationData.mainInvitationText.romanticLine}"
        </p>
      </motion.div>
    </div>
  );
};
