import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Play, Pause, ChevronLeft, ChevronRight, Check } from "lucide-react";
import { invitationData } from "../config/invitationData";

const Petal = ({ id }: { id: number }) => {
  const startX = Math.random() * 100;
  const duration = 5 + Math.random() * 4;
  const delay = Math.random() * 3;

  return (
    <motion.div
      key={id}
      initial={{ top: "-5%", left: `${startX}%`, opacity: 0, rotate: 0 }}
      animate={{
        top: "105%",
        left: `${startX + (Math.random() * 14 - 7)}%`,
        opacity: [0, 0.85, 0.85, 0],
        rotate: [0, 180, 360],
      }}
      transition={{
        duration,
        repeat: Infinity,
        delay,
        ease: "linear",
      }}
      style={{
        position: "absolute",
        pointerEvents: "none",
        width: "12px",
        height: "16px",
        backgroundColor: "rgba(142, 28, 43, 0.8)",
        borderRadius: "60% 0 60% 60%",
        transform: "rotate(35deg)",
        filter: "blur(0.2px)",
        boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
        zIndex: 35,
      }}
    />
  );
};

interface WeddingTeklilInvitationProps {
  onOpen?: () => void;
  isOpenState?: boolean;
}

export default function WeddingTeklilInvitation({ onOpen, isOpenState }: WeddingTeklilInvitationProps) {
  const [isOpen, setIsOpen] = useState(isOpenState || false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlayingStory, setIsPlayingStory] = useState(true);
  const [rsvpDone, setRsvpDone] = useState(false);

  const totalSlides = 4;

  useEffect(() => {
    if (isOpenState !== undefined) {
      setIsOpen(isOpenState);
    }
  }, [isOpenState]);

  useEffect(() => {
    if (!isOpen || !isPlayingStory) return;

    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % totalSlides);
    }, 6000);

    return () => clearInterval(timer);
  }, [isOpen, isPlayingStory]);

  const handleOpenCard = () => {
    setIsOpen(true);
    setCurrentSlide(0);
    setIsPlayingStory(true);
    if (onOpen) onOpen();
  };

  const slides = [
    // Slide 1: Sacred Trinitarian Invocation & Scripture
    {
      id: 1,
      content: (
        <div className="flex flex-col items-center justify-center h-full text-center px-4 pt-16 pb-4 select-none">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col gap-3 my-auto"
          >
            <div className="inline-flex items-center justify-center gap-1.5 px-3 py-1 rounded-full bg-[#8B2635]/10 border border-[#8B2635]/25 mx-auto">
              <span className="text-[#8B2635] text-sm font-bold">✝</span>
              <span className="text-xs font-serif font-bold text-[#8B2635] tracking-widest uppercase">
                በስመ አብ
              </span>
            </div>

            <h2 className="font-serif text-lg md:text-xl font-bold text-[#3B1E12] leading-relaxed">
              በስመ አብ ወወልድ ወመንፈስ ቅዱስ<br />አሐዱ አምላክ አሜን
            </h2>

            <div className="w-16 h-[1.5px] bg-[#C59B27] mx-auto rounded-full my-1" />

            <p className="font-serif text-sm md:text-base italic text-[#7A4026] leading-relaxed font-semibold">
              "In the name of the Father, & and of the Son, and of the Holy Spirit"
            </p>

            <blockquote className="mt-2 text-xs md:text-sm font-serif text-[#8B2635] bg-white/70 p-3 rounded-xl border border-[#8B2635]/20 shadow-sm backdrop-blur-sm">
              "እንግዲህ እግዚአብሔር ያጣመረውን ሰው አይለየውም"
              <span className="block mt-1 text-[11px] font-bold text-[#A87928] tracking-widest">
                — ማቴዎስ ፲፱ ፥ ፮
              </span>
            </blockquote>
          </motion.div>
        </div>
      ),
    },

    // Slide 2: Twin Royal Crowns & Holy Matrimony
    {
      id: 2,
      content: (
        <div className="flex flex-col items-center justify-center h-full text-center px-4 pt-16 pb-4 select-none">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col items-center gap-4 my-auto w-full"
          >
            {/* Twin Crowns Motif */}
            <div className="flex items-center justify-center gap-4">
              <motion.div
                animate={{ y: [0, -4, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className="flex flex-col items-center"
              >
                <span className="text-4xl filter drop-shadow-md">👑</span>
                <span className="text-[10px] font-bold text-[#A87928] tracking-widest mt-1">አክሊል</span>
              </motion.div>

              <span className="text-2xl text-[#8B2635] font-serif font-bold">✝</span>

              <motion.div
                animate={{ y: [0, -4, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 0.4 }}
                className="flex flex-col items-center"
              >
                <span className="text-4xl filter drop-shadow-md">👑</span>
                <span className="text-[10px] font-bold text-[#A87928] tracking-widest mt-1">አክሊል</span>
              </motion.div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-xs uppercase tracking-[3px] text-[#A87928] font-bold">
                Holy Matrimony
              </span>
              <h3 className="font-serif text-2xl md:text-3xl font-bold text-[#1E5F38] tracking-wide">
                ሥርዓተ ተክሊል
              </h3>
            </div>

            <div className="p-4 rounded-2xl bg-white/75 border border-[#E5D7C6] shadow-sm backdrop-blur-sm">
              <p className="font-serif text-xs md:text-sm text-[#3B1E12] leading-relaxed italic">
                "{invitationData.mainInvitationText.romanticLine}"
              </p>
              <div className="mt-2 text-xs font-serif font-bold text-[#8B2635]">
                {invitationData.mainInvitationText.familyHeader}
              </div>
            </div>
          </motion.div>
        </div>
      ),
    },

    // Slide 3: Couple Announcement & Families
    {
      id: 3,
      content: (
        <div className="flex flex-col items-center justify-center h-full text-center px-3 pt-16 pb-4 select-none">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col items-center gap-3 my-auto w-full"
          >
            <span className="text-xs uppercase tracking-[3px] text-[#8B5A2B] font-bold">
              Together with their families
            </span>

            <div className="p-4 w-full rounded-2xl bg-white/80 border border-[#E8DCCB] shadow-md backdrop-blur-sm">
              <div className="flex flex-col items-center mb-1">
                <span className="font-serif text-2xl md:text-3xl font-bold text-[#8B2635] tracking-wide">
                  {invitationData.groom.name}
                </span>
                <span className="text-[11px] font-sans text-[#7A4026] font-medium">
                  {invitationData.groom.family}
                </span>
              </div>

              <div className="flex items-center justify-center gap-3 my-1">
                <div className="w-8 h-[1px] bg-[#C59B27]" />
                <span className="font-serif text-xl italic text-[#C59B27] font-bold">&</span>
                <div className="w-8 h-[1px] bg-[#C59B27]" />
              </div>

              <div className="flex flex-col items-center mt-1">
                <span className="font-serif text-2xl md:text-3xl font-bold text-[#8B2635] tracking-wide">
                  {invitationData.bride.name}
                </span>
                <span className="text-[11px] font-sans text-[#7A4026] font-medium">
                  {invitationData.bride.family}
                </span>
              </div>
            </div>

            <p className="text-[11px] font-serif italic text-[#7A4026]">
              Solicit your gracious presence & prayers
            </p>
          </motion.div>
        </div>
      ),
    },

    // Slide 4: Date, Times & Venues
    {
      id: 4,
      content: (
        <div className="flex flex-col items-center justify-center h-full text-center px-3 pt-16 pb-2 select-none">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="flex flex-col gap-2 w-full my-auto"
          >
            <div>
              <span className="text-xs uppercase tracking-widest text-[#1E5F38] font-bold block">
                Sunday, November 22, 2026
              </span>
              <span className="font-serif text-xs text-[#7A4026] font-semibold">
                እሑድ ኅዳር ፲፫ ቀን ፪ሺ፲፱ ዓ.ም.
              </span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/85 border border-[#E5D7C6] shadow-sm text-left">
              <div>
                <div className="text-xs font-bold text-[#3B1E12]">⛪ Crowning (ሥርዓተ ተክሊል)</div>
                <div className="text-[11px] text-[#7A4026] mt-0.5">{invitationData.ceremony.venue}</div>
              </div>
              <span className="text-xs font-bold text-[#8B2635] bg-[#8B2635]/10 px-2 py-1 rounded-md">
                10:30 AM
              </span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/85 border border-[#E5D7C6] shadow-sm text-left">
              <div>
                <div className="text-xs font-bold text-[#3B1E12]">🥂 Reception (የሠርግ ምሽት)</div>
                <div className="text-[11px] text-[#7A4026] mt-0.5">{invitationData.reception.venue}</div>
              </div>
              <span className="text-xs font-bold text-[#1E5F38] bg-[#1E5F38]/10 px-2 py-1 rounded-md">
                06:00 PM
              </span>
            </div>

            <div className="pt-1">
              {!rsvpDone ? (
                <button
                  onClick={() => setRsvpDone(true)}
                  className="w-full py-2 px-3 rounded-xl bg-[#8B2635] text-white font-sans text-xs font-bold shadow-md hover:bg-[#721c29] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Check size={14} />
                  <span>በክብር ተቀብያለሁ • Confirm Attendance</span>
                </button>
              ) : (
                <div className="p-2 rounded-xl bg-[#1E5F38]/15 border border-[#1E5F38]/30 text-[#1E5F38] text-xs font-bold flex items-center justify-center gap-1.5">
                  <Check size={14} />
                  <span>መገኘትዎን አረጋግጠዋል! እናመሰግናለን (RSVP Confirmed)</span>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      ),
    },
  ];

  return (
    <div className="w-full flex flex-col items-center justify-center select-none">
      {/* 3D Gatefold Card Container */}
      <div
        className="relative w-full max-w-[390px] h-[670px] rounded-3xl bg-[#FAF5EE] shadow-[0_25px_60px_rgba(0,0,0,0.85)] overflow-hidden border border-[#A06E3C]/40"
        style={{ perspective: "1500px" }}
      >
        {/* Floating Rose Petals Layer */}
        <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden">
          {Array.from({ length: 14 }).map((_, i) => (
            <Petal key={i} id={i} />
          ))}
        </div>

        {/* Top & Bottom Traditional Gold Ethiopian Ribbon Edge */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-[#8B2635] via-[#C59B27] to-[#1E5F38] z-30" />
        <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-gradient-to-r from-[#1E5F38] via-[#C59B27] to-[#8B2635] z-30" />

        {/* CLEAN INNER CARD (Pure columns, doves, parchment background from frame 3) */}
        <div
          className="absolute inset-0 p-4 flex flex-col justify-between"
          style={{
            backgroundImage: "url('/assets/orthodox/clean_inner_frame.jpg')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        >
          {/* Story Progress Bars at Top */}
          {isOpen && (
            <div className="w-full flex items-center gap-1.5 z-20 pt-1 px-1">
              {Array.from({ length: totalSlides }).map((_, index) => (
                <div
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className="flex-1 h-1 rounded-full bg-black/20 overflow-hidden cursor-pointer"
                >
                  <div
                    className={`h-full transition-all duration-300 ${
                      index === currentSlide
                        ? "bg-[#8B2635] w-full"
                        : index < currentSlide
                        ? "bg-[#8B2635]/60 w-full"
                        : "w-0"
                    }`}
                  />
                </div>
              ))}
            </div>
          )}

          {/* Active Story Scene with Motion */}
          <div className="w-full flex-1 flex flex-col justify-center z-10">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentSlide}
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.04 }}
                transition={{ duration: 0.5 }}
                className="w-full h-full"
              >
                {slides[currentSlide].content}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Bottom Card Controls (Prev, Next, Play/Pause) */}
          {isOpen && (
            <div className="w-full flex items-center justify-between pt-1 border-t border-[#8B5A2B]/20 z-20 px-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentSlide((p) => (p > 0 ? p - 1 : totalSlides - 1))}
                  className="w-7 h-7 rounded-full bg-white/85 border border-[#8B5A2B]/30 flex items-center justify-center text-xs font-bold text-[#3B1E12] shadow-sm hover:bg-white cursor-pointer"
                  title="Previous Scene"
                >
                  <ChevronLeft size={16} />
                </button>
                <button
                  onClick={() => setIsPlayingStory(!isPlayingStory)}
                  className="w-7 h-7 rounded-full bg-white/85 border border-[#8B5A2B]/30 flex items-center justify-center text-xs font-bold text-[#8B2635] shadow-sm hover:bg-white cursor-pointer"
                  title={isPlayingStory ? "Pause Autoplay" : "Resume Autoplay"}
                >
                  {isPlayingStory ? <Pause size={12} /> : <Play size={12} />}
                </button>
                <button
                  onClick={() => setCurrentSlide((p) => (p < totalSlides - 1 ? p + 1 : 0))}
                  className="w-7 h-7 rounded-full bg-white/85 border border-[#8B5A2B]/30 flex items-center justify-center text-xs font-bold text-[#3B1E12] shadow-sm hover:bg-white cursor-pointer"
                  title="Next Scene"
                >
                  <ChevronRight size={16} />
                </button>
              </div>

              <span className="text-[11px] font-serif font-bold text-[#8B5A2B]">
                {currentSlide + 1} / {totalSlides}
              </span>
            </div>
          )}
        </div>

        {/* LEFT 3D GATEFOLD DOOR */}
        <motion.div
          animate={{
            rotateY: isOpen ? -120 : 0,
            x: isOpen ? "-15%" : "0%",
          }}
          transition={{ duration: 1.4, ease: [0.65, 0, 0.35, 1] }}
          className="absolute top-0 left-0 w-1/2 h-full z-40 bg-[#FAF7F2] border-r border-[#8B5A2B]/30 shadow-[10px_0_25px_rgba(0,0,0,0.25)] cursor-pointer"
          style={{
            transformOrigin: "left center",
            backgroundImage: "url('/assets/orthodox/door_left.jpg')",
            backgroundSize: "cover",
            backgroundPosition: "left center",
          }}
          onClick={!isOpen ? handleOpenCard : undefined}
        >
          {/* Left half of split wax seal */}
          <div
            className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-1/2 z-50 pointer-events-none"
            style={{ width: "80px", height: "80px" }}
          >
            <img
              src="/assets/orthodox/wax_seal_left.png"
              alt="Wax seal left"
              className="w-full h-full object-contain filter drop-shadow-[0_4px_10px_rgba(0,0,0,0.4)]"
            />
          </div>
        </motion.div>

        {/* RIGHT 3D GATEFOLD DOOR */}
        <motion.div
          animate={{
            rotateY: isOpen ? 120 : 0,
            x: isOpen ? "15%" : "0%",
          }}
          transition={{ duration: 1.4, ease: [0.65, 0, 0.35, 1] }}
          className="absolute top-0 right-0 w-1/2 h-full z-40 bg-[#FAF7F2] border-l border-[#8B5A2B]/30 shadow-[-10px_0_25px_rgba(0,0,0,0.25)] cursor-pointer"
          style={{
            transformOrigin: "right center",
            backgroundImage: "url('/assets/orthodox/door_right.jpg')",
            backgroundSize: "cover",
            backgroundPosition: "right center",
          }}
          onClick={!isOpen ? handleOpenCard : undefined}
        >
          {/* Right half of split wax seal */}
          <div
            className="absolute top-1/2 left-0 -translate-y-1/2 -translate-x-1/2 z-50 pointer-events-none"
            style={{ width: "80px", height: "80px" }}
          >
            <img
              src="/assets/orthodox/wax_seal_right.png"
              alt="Wax seal right"
              className="w-full h-full object-contain filter drop-shadow-[0_4px_10px_rgba(0,0,0,0.4)]"
            />
          </div>
        </motion.div>

        {/* WHITE SATIN RIBBON & CLICKABLE WAX SEAL BADGE (Only when Closed) */}
        {!isOpen && (
          <div className="absolute inset-0 z-50 flex items-center justify-center pointer-events-none">
            {/* Satin Ribbon Horizontal Sash */}
            <div className="absolute w-full h-12 bg-white/95 border-y border-[#E2D7C8] shadow-[0_4px_16px_rgba(0,0,0,0.12)] flex items-center justify-between px-4">
              <span className="text-[10px] font-serif font-bold text-[#A87928] tracking-widest uppercase">
                Holy Matrimony
              </span>
              <span className="text-[10px] font-serif font-bold text-[#A87928] tracking-widest uppercase">
                ሥርዓተ ተክሊል
              </span>
            </div>

            {/* Tap Wax Seal Button with Pulse & Guidance */}
            <motion.button
              whileTap={{ scale: 0.92 }}
              whileHover={{ scale: 1.05 }}
              onClick={handleOpenCard}
              className="pointer-events-auto relative flex flex-col items-center justify-center cursor-pointer group"
              title="Click to Open the Invitation"
            >
              {/* Outer Glowing Pulse Ring */}
              <motion.div
                animate={{ scale: [1, 1.25, 1], opacity: [0.6, 0, 0.6] }}
                transition={{ duration: 2.2, repeat: Infinity }}
                className="absolute w-28 h-28 rounded-full bg-[#8B2635]/30 -z-10"
              />

              {/* Full Wax Seal Image with Cross */}
              <div className="w-24 h-24 rounded-full overflow-hidden shadow-[0_10px_30px_rgba(110,20,30,0.6)] border-2 border-[#9E3440]">
                <img
                  src="/assets/orthodox/wax_seal_full.png"
                  alt="Ethiopian Orthodox Cross Wax Seal"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Helper invitation tooltip */}
              <motion.div
                animate={{ y: [0, 4, 0] }}
                transition={{ duration: 1.8, repeat: Infinity }}
                className="mt-3 px-3 py-1 rounded-full bg-[#3B1E12]/90 border border-[#C59B27]/50 text-[#F5EADB] text-[11px] font-serif font-bold tracking-wider shadow-md backdrop-blur-sm"
              >
                ✦ ማኅተሙን ይጫኑ • Tap to Open ✦
              </motion.div>
            </motion.button>
          </div>
        )}
      </div>
    </div>
  );
}
