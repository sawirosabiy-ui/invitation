import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, ExternalLink } from 'lucide-react';
import { invitationData } from '../config/invitationData';

export const LocationSection: React.FC = () => {
  return (
    <div className="w-full max-w-xl mx-auto px-4 py-6 text-center select-none">
      <motion.div
        initial={{ opacity: 0, y: 25 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.9 }}
        className="relative p-6 md:p-8 rounded-3xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-xl"
      >
        <span className="font-serif text-xs uppercase tracking-[0.25em] text-[#1b4d2e] font-semibold block mb-1">
          Venue &amp; Directions
        </span>

        <h3 className="font-serif text-2xl md:text-3xl font-bold text-[#7a1b22] mb-2">
          {invitationData.location.name}
        </h3>

        <p className="font-sans text-xs md:text-sm text-[#4d1015]/80 font-medium mb-6">
          {invitationData.location.address}
        </p>

        {invitationData.location.mapUrl && (
          <a
            href={invitationData.location.mapUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#7a1b22] text-[#f8f3e6] border border-[#e6d8be] text-xs font-sans tracking-widest uppercase font-semibold hover:bg-[#9e222d] transition-all duration-300 shadow-md cursor-pointer"
          >
            <MapPin size={14} />
            <span>View Location</span>
            <ExternalLink size={12} />
          </a>
        )}
      </motion.div>
    </div>
  );
};
