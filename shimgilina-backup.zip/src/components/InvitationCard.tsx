import React from 'react';
import { motion } from 'framer-motion';
import { invitationData } from '../config/invitationData';

export const InvitationCard: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 1 }}
      className="w-full max-w-xl mx-auto px-4 my-8 text-center"
    >
      <div className="relative p-8 md:p-12 rounded-3xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-2xl shadow-[#7a1b22]/15 backdrop-blur-md overflow-hidden">
        {/* Scalloped Rose Corner Accents */}
        <div className="absolute top-3 left-3 text-[#7a1b22]/40 text-xs">🌹</div>
        <div className="absolute top-3 right-3 text-[#7a1b22]/40 text-xs">🌹</div>
        <div className="absolute bottom-3 left-3 text-[#7a1b22]/40 text-xs">🌹</div>
        <div className="absolute bottom-3 right-3 text-[#7a1b22]/40 text-xs">🌹</div>

        <span className="font-serif text-xs uppercase tracking-[0.25em] text-[#1b4d2e] font-semibold">
          Invitation Card
        </span>

        <h3 className="font-serif text-3xl font-bold text-[#7a1b22] my-3">
          {invitationData.title}
        </h3>

        <div className="py-2">
          <p className="font-['Alex_Brush',_cursive] text-4xl text-[#1b4d2e]">
            {invitationData.groom.name} &amp; {invitationData.bride.name}
          </p>
        </div>

        <div className="w-16 h-[1px] bg-[#7a1b22]/30 mx-auto my-4" />

        <p className="font-serif italic text-base md:text-lg text-[#7a1b22] leading-relaxed max-w-md mx-auto">
          "{invitationData.invitationMessage}"
        </p>
      </div>
    </motion.div>
  );
};
