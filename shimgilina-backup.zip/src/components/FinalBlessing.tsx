import React from 'react';
import { motion } from 'framer-motion';
import { OrthodoxCross } from './OrthodoxCross';
import { RotateCcw } from 'lucide-react';
import { invitationData } from '../config/invitationData';

interface FinalBlessingProps {
  onReplay: () => void;
}

export const FinalBlessing: React.FC<FinalBlessingProps> = ({ onReplay }) => {
  return (
    <div className="w-full max-w-xl mx-auto px-4 py-8 text-center select-none">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="flex flex-col items-center"
      >
        <OrthodoxCross size={32} className="text-[#7a1b22] mb-4" />

        <p className="font-serif italic text-xl md:text-2xl text-[#7a1b22] max-w-md leading-relaxed font-semibold mb-4">
          "{invitationData.closingMessage}"
        </p>

        <div className="w-20 h-[2px] bg-[#7a1b22]/30 my-4" />

        <p className="font-serif text-sm tracking-wider uppercase text-[#1b4d2e] font-bold mb-2">
          {invitationData.groom.name} &amp; {invitationData.bride.name}
        </p>

        <p className="font-sans text-xs text-[#7a1b22]/80 uppercase tracking-widest mb-8 font-medium">
          {invitationData.groom.family} • {invitationData.bride.family}
        </p>

        <button
          onClick={onReplay}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#fdfbf7] border-2 border-[#7a1b22]/30 text-xs font-sans tracking-widest uppercase text-[#7a1b22] font-semibold hover:bg-[#7a1b22] hover:text-[#f8f3e6] transition-all duration-300 cursor-pointer shadow-sm"
        >
          <RotateCcw size={13} />
          <span>Replay Invitation</span>
        </button>
      </motion.div>
    </div>
  );
};
