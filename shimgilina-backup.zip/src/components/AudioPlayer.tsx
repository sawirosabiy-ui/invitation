import React, { useRef, useEffect, useState } from 'react';
import { Volume2, VolumeX, Music } from 'lucide-react';

interface AudioPlayerProps {
  shouldPlay: boolean;
  audioUrl?: string;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({
  shouldPlay,
  audioUrl = "/invitation-audio.mp3",
}) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (shouldPlay) {
      audio.play().then(() => {
        setIsPlaying(true);
      }).catch((err) => {
        console.log("Audio autoplay prevented by browser:", err);
      });
    }
  }, [shouldPlay]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => {
        setIsPlaying(true);
      }).catch(console.error);
    }
  };

  const toggleMute = () => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  return (
    <div className="fixed top-5 right-5 z-50 flex items-center gap-2">
      <audio
        ref={audioRef}
        src={audioUrl}
        loop
        preload="auto"
      />

      {/* Floating Audio Control Button */}
      <button
        onClick={togglePlay}
        className="group relative flex items-center gap-2 px-3 py-2 rounded-full bg-[#18141e]/90 border border-[#d4af37]/40 shadow-xl shadow-black/80 backdrop-blur-md text-[#f3e5ab] hover:border-[#d4af37] transition-all duration-300 cursor-pointer"
        title={isPlaying ? "Pause Music" : "Play Music"}
      >
        {isPlaying ? (
          <>
            <Music size={14} className="text-[#d4af37] animate-pulse" />
            {/* Animated Equalizer Bars */}
            <div className="flex items-end gap-[2px] h-3 px-1">
              <span className="w-[2px] h-3 bg-[#d4af37] animate-bounce" style={{ animationDuration: '0.6s' }} />
              <span className="w-[2px] h-2 bg-[#f3e5ab] animate-bounce" style={{ animationDuration: '0.9s' }} />
              <span className="w-[2px] h-3.5 bg-[#d4af37] animate-bounce" style={{ animationDuration: '0.7s' }} />
            </div>
          </>
        ) : (
          <Music size={14} className="text-[#a89b88]" />
        )}
      </button>

      {/* Mute Toggle */}
      {isPlaying && (
        <button
          onClick={toggleMute}
          className="p-2 rounded-full bg-[#18141e]/90 border border-[#d4af37]/30 text-[#f3e5ab] hover:border-[#d4af37] backdrop-blur-md transition-all duration-300 cursor-pointer"
          title={isMuted ? "Unmute" : "Mute"}
        >
          {isMuted ? <VolumeX size={14} className="text-red-400" /> : <Volume2 size={14} className="text-[#d4af37]" />}
        </button>
      )}
    </div>
  );
};
