import React, { useRef, useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Hand } from 'lucide-react';
import { invitationData } from '../config/invitationData';

interface SceneScratchRevealProps {
  onRevealed: () => void;
  isRevealed: boolean;
}

export const SceneScratchReveal: React.FC<SceneScratchRevealProps> = ({
  onRevealed,
  isRevealed,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [scratchProgress, setScratchProgress] = useState(0);
  const [hasInteracted, setHasInteracted] = useState(false);

  // Initialize Canvas Scratch Layer with Rose Gold Parchment Texture
  const initCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;

    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    // Deep crimson rose gold foil gradient
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, '#7a1b22');
    gradient.addColorStop(0.4, '#b52b36');
    gradient.addColorStop(0.7, '#d4a325');
    gradient.addColorStop(1, '#64171d');

    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Decorative grid on scratch layer
    ctx.strokeStyle = 'rgba(255, 243, 220, 0.25)';
    ctx.lineWidth = 1;
    for (let x = 0; x < width; x += 24) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    // Instruction text
    ctx.fillStyle = '#f8f3e6';
    ctx.font = '600 13px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('✦ SCRATCH TO DISCOVER THE DATE ✦', width / 2, height / 2 - 10);

    ctx.font = 'italic 12px "Cormorant Garamond", serif';
    ctx.fillStyle = '#fce8d5';
    ctx.fillText('Swipe or drag across to reveal', width / 2, height / 2 + 12);
  }, []);

  useEffect(() => {
    initCanvas();
    window.addEventListener('resize', initCanvas);
    return () => window.removeEventListener('resize', initCanvas);
  }, [initCanvas]);

  const calculateProgress = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || isRevealed) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    let transparentPixels = 0;

    for (let i = 3; i < pixels.length; i += 16) {
      if (pixels[i] < 128) {
        transparentPixels++;
      }
    }

    const totalSampledPixels = pixels.length / 16;
    const progress = transparentPixels / totalSampledPixels;
    setScratchProgress(progress);

    if (progress >= 0.60 && !isRevealed) {
      onRevealed();
    }
  }, [isRevealed, onRevealed]);

  const scratch = useCallback((clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas || isRevealed) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x, y, 28, 0, Math.PI * 2);
    ctx.fill();

    if (!hasInteracted) setHasInteracted(true);
    calculateProgress();
  }, [calculateProgress, hasInteracted, isRevealed]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDrawing(true);
    scratch(e.clientX, e.clientY);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDrawing) return;
    scratch(e.clientX, e.clientY);
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDrawing(true);
    if (e.touches.length > 0) {
      scratch(e.touches[0].clientX, e.touches[0].clientY);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDrawing) return;
    if (e.touches.length > 0) {
      if (e.cancelable) e.preventDefault();
      scratch(e.touches[0].clientX, e.touches[0].clientY);
    }
  };

  const handleTouchEnd = () => {
    setIsDrawing(false);
  };

  return (
    <div className="w-full max-w-lg mx-auto px-4 py-6 text-center select-none" ref={containerRef}>
      {/* Discovery Prompt Headers */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="mb-6"
      >
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#7a1b22]/10 border border-[#7a1b22]/30 text-[#7a1b22] text-xs font-sans tracking-wider uppercase mb-2 font-semibold">
          <Sparkles size={13} className="text-[#7a1b22]" />
          <span>Discovery Moment</span>
        </div>
        <h3 className="font-serif text-2xl md:text-3xl font-bold text-[#7a1b22] mb-1">
          A special moment awaits...
        </h3>
        <p className="font-sans text-xs tracking-widest uppercase text-[#1b4d2e] font-medium">
          Scratch to discover the date
        </p>
      </motion.div>

      {/* Interactive Scratch Card Frame */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.9 }}
        className="relative w-full max-w-md mx-auto aspect-[16/9] md:aspect-[2/1] rounded-2xl overflow-hidden border-2 border-[#7a1b22]/40 shadow-xl shadow-[#7a1b22]/15 bg-[#fdfbf7] group"
      >
        {/* Hidden Content Underneath */}
        <div className="absolute inset-0 flex flex-col items-center justify-center p-6 bg-gradient-to-br from-[#fdfbf7] via-[#f8f2e4] to-[#f4ece0] text-center">
          <p className="font-serif italic text-sm text-[#7a1b22] font-semibold mb-1">
            The Official Date
          </p>
          <div className="font-serif text-3xl md:text-4xl font-bold tracking-wide text-[#1b4d2e] my-1">
            {invitationData.date.formatted}
          </div>
          <p className="font-sans text-xs uppercase tracking-widest text-[#7a1b22] font-medium mt-1">
            {invitationData.time}
          </p>
        </div>

        {/* Scratch Canvas Overlay */}
        <AnimatePresence>
          {!isRevealed && (
            <motion.canvas
              ref={canvasRef}
              exit={{ opacity: 0, scale: 1.05, transition: { duration: 0.8, ease: "easeOut" } }}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              className="absolute inset-0 w-full h-full cursor-pointer touch-none z-20"
            />
          )}
        </AnimatePresence>

        {!hasInteracted && !isRevealed && (
          <div className="absolute bottom-3 right-3 z-30 pointer-events-none flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#7a1b22] text-[#f8f3e6] border border-[#e6d8be] text-[10px] animate-pulse shadow-md">
            <Hand size={12} />
            <span>Scratch with finger / cursor</span>
          </div>
        )}
      </motion.div>

      {!isRevealed && (
        <div className="mt-4 flex flex-col items-center gap-2">
          {scratchProgress > 0 && (
            <div className="w-48 h-1.5 bg-[#e8dcc4] rounded-full overflow-hidden border border-[#7a1b22]/20">
              <div
                className="h-full bg-[#7a1b22] transition-all duration-200"
                style={{ width: `${Math.min(Math.round(scratchProgress * 100), 100)}%` }}
              />
            </div>
          )}

          <button
            onClick={onRevealed}
            className="text-[11px] font-sans tracking-widest uppercase text-[#7a1b22] hover:text-[#9e222d] underline underline-offset-4 transition-colors cursor-pointer mt-1 font-semibold"
          >
            Click here to reveal immediately
          </button>
        </div>
      )}
    </div>
  );
};
