import React from 'react';

interface OrthodoxCrossProps {
  className?: string;
  size?: number;
  variant?: 'subtle' | 'gold' | 'ornate';
}

export const OrthodoxCross: React.FC<OrthodoxCrossProps> = ({
  className = "w-6 h-6 text-[#d4af37]",
  size = 32,
  variant = 'gold',
}) => {
  if (variant === 'ornate') {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        <path
          d="M50 8 V92 M26 28 H74 M32 46 H68 M32 78 L68 66"
          stroke="currentColor"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="50" cy="50" r="14" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 3" />
        <circle cx="50" cy="8" r="3" fill="currentColor" />
        <circle cx="50" cy="92" r="3" fill="currentColor" />
        <circle cx="26" cy="28" r="3" fill="currentColor" />
        <circle cx="74" cy="28" r="3" fill="currentColor" />
      </svg>
    );
  }

  // Classic Eastern/Ethiopian Orthodox Cross vector lines
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Top Crossbar */}
      <path
        d="M18 14H30"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
      {/* Main Horizontal Arm */}
      <path
        d="M12 20H36"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      {/* Vertical Shaft */}
      <path
        d="M24 6V42"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      {/* Bottom Slanted Footrest Bar */}
      <path
        d="M16 35L32 30"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
      {/* Decorative center halo ring */}
      <circle cx="24" cy="20" r="6" stroke="currentColor" strokeWidth="1" strokeOpacity="0.6" />
    </svg>
  );
};
