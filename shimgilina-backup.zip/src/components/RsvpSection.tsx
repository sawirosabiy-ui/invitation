import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, CheckCircle2 } from 'lucide-react';

export const RsvpSection: React.FC = () => {
  const [guestName, setGuestName] = useState('');
  const [attendance, setAttendance] = useState<'accept' | 'decline'>('accept');
  const [guestCount, setGuestCount] = useState(1);
  const [note, setNote] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) return;
    setSubmitted(true);
  };

  return (
    <div className="w-full max-w-xl mx-auto px-4 py-8 select-none">
      <motion.div
        initial={{ opacity: 0, y: 25 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.9 }}
        className="relative p-6 md:p-10 rounded-3xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-2xl shadow-[#7a1b22]/15 overflow-hidden"
      >
        <div className="text-center mb-6">
          <span className="font-serif text-xs uppercase tracking-[0.3em] text-[#1b4d2e] font-semibold block mb-1">
            R S V P
          </span>
          <h3 className="font-serif text-3xl font-bold text-[#7a1b22]">
            Will You Join Us?
          </h3>
          <p className="font-serif italic text-sm text-[#4d1015]/80 mt-1">
            Please let us know if you can share in our special day.
          </p>
        </div>

        {submitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="p-8 text-center bg-[#f8f3e6] rounded-2xl border border-[#7a1b22]/20"
          >
            <div className="inline-flex p-3 rounded-full bg-[#7a1b22]/10 text-[#7a1b22] mb-3">
              <CheckCircle2 size={32} />
            </div>
            <h4 className="font-serif text-2xl font-bold text-[#7a1b22] mb-2">
              Thank You, {guestName}!
            </h4>
            <p className="font-serif italic text-base text-[#1b4d2e]">
              {attendance === 'accept'
                ? `We are overjoyed to celebrate with you (${guestCount} guest${guestCount > 1 ? 's' : ''})!`
                : "Thank you for sending your warm wishes. You will be in our thoughts."}
            </p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Guest Name */}
            <div>
              <label className="block font-serif text-xs uppercase tracking-wider text-[#7a1b22] font-semibold mb-1">
                Your Full Name *
              </label>
              <input
                type="text"
                required
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                placeholder="e.g. Samuel & Martha"
                className="w-full px-4 py-3 rounded-xl bg-[#f8f2e4] border border-[#7a1b22]/30 text-[#4d1015] font-serif placeholder-[#4d1015]/40 focus:outline-none focus:border-[#7a1b22] transition-colors"
              />
            </div>

            {/* Attendance Choice */}
            <div>
              <label className="block font-serif text-xs uppercase tracking-wider text-[#7a1b22] font-semibold mb-2">
                Attendance
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setAttendance('accept')}
                  className={`py-3 px-4 rounded-xl border text-xs font-serif font-bold transition-all cursor-pointer ${
                    attendance === 'accept'
                      ? 'bg-[#7a1b22] text-[#f8f3e6] border-[#7a1b22] shadow-md'
                      : 'bg-[#f8f2e4] text-[#7a1b22] border-[#7a1b22]/30 hover:bg-[#f2e9d8]'
                  }`}
                >
                  Joyfully Accepts
                </button>
                <button
                  type="button"
                  onClick={() => setAttendance('decline')}
                  className={`py-3 px-4 rounded-xl border text-xs font-serif font-bold transition-all cursor-pointer ${
                    attendance === 'decline'
                      ? 'bg-[#7a1b22] text-[#f8f3e6] border-[#7a1b22] shadow-md'
                      : 'bg-[#f8f2e4] text-[#7a1b22] border-[#7a1b22]/30 hover:bg-[#f2e9d8]'
                  }`}
                >
                  Regretfully Declines
                </button>
              </div>
            </div>

            {/* Number of Guests */}
            {attendance === 'accept' && (
              <div>
                <label className="block font-serif text-xs uppercase tracking-wider text-[#7a1b22] font-semibold mb-1">
                  Number of Guests
                </label>
                <select
                  value={guestCount}
                  onChange={(e) => setGuestCount(Number(e.target.value))}
                  className="w-full px-4 py-3 rounded-xl bg-[#f8f2e4] border border-[#7a1b22]/30 text-[#4d1015] font-serif focus:outline-none focus:border-[#7a1b22] transition-colors"
                >
                  <option value={1}>1 Guest</option>
                  <option value={2}>2 Guests</option>
                  <option value={3}>3 Guests</option>
                  <option value={4}>4 Guests</option>
                </select>
              </div>
            )}

            {/* Optional Note */}
            <div>
              <label className="block font-serif text-xs uppercase tracking-wider text-[#7a1b22] font-semibold mb-1">
                Warm Message or Note (Optional)
              </label>
              <textarea
                rows={3}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Share a blessing or message for the couple..."
                className="w-full px-4 py-3 rounded-xl bg-[#f8f2e4] border border-[#7a1b22]/30 text-[#4d1015] font-serif placeholder-[#4d1015]/40 focus:outline-none focus:border-[#7a1b22] transition-colors"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-4 rounded-full bg-[#7a1b22] text-[#f8f3e6] font-serif text-sm font-bold tracking-widest uppercase hover:bg-[#9e222d] transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              <Send size={16} />
              <span>Send RSVP</span>
            </button>
          </form>
        )}
      </motion.div>
    </div>
  );
};
