import React from 'react';
import { motion } from 'framer-motion';

export const DoveScene: React.FC = () => {
  return (
    <div className="relative w-full h-40 my-4 overflow-hidden pointer-events-none flex items-center justify-center">
      {/* Left White Dove Flying to Center */}
      <motion.div
        initial={{ x: '-120%', y: 20, opacity: 0, scale: 0.8 }}
        animate={{
          x: ['-100%', '-20%', '0%'],
          y: [30, -10, 0],
          opacity: [0, 1, 1],
          scale: [0.8, 1, 1],
        }}
        transition={{ duration: 3.5, ease: 'easeInOut' }}
        className="absolute left-1/2 -translate-x-full flex items-center gap-2"
      >
        {/* SVG Flying White Dove Left */}
        <div className="relative">
          <svg width="65" height="50" viewBox="0 0 100 80" fill="none" className="drop-shadow-md">
            {/* Flapping Wing Left */}
            <motion.path
              d="M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z"
              fill="#ffffff"
              animate={{ d: [
                "M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z",
                "M50 40 C35 30, 20 40, 10 50 C20 48, 32 45, 45 42 Z",
                "M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z"
              ] }}
              transition={{ repeat: Infinity, duration: 0.5, ease: "easeInOut" }}
            />
            {/* Body */}
            <path d="M40 40 C55 40, 75 35, 85 40 C95 45, 90 55, 75 55 C60 55, 45 50, 40 40 Z" fill="#fdfbf7" />
            {/* Tail feathers */}
            <path d="M15 45 L0 40 L5 52 L20 48 Z" fill="#f4ece0" />
            {/* Beak & Eye */}
            <circle cx="82" cy="42" r="1.5" fill="#7a1b22" />
            <path d="M86 43 L94 45 L87 47 Z" fill="#d4a325" />
          </svg>

          {/* Golden Silk Ribbon Trail */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 2, delay: 0.5 }}
            className="absolute top-1/2 right-full w-32 h-[2px] bg-gradient-to-l from-[#d4a325] via-[#7a1b22]/40 to-transparent -translate-y-1/2 origin-right"
          />
        </div>
      </motion.div>

      {/* Right White Dove Flying to Center */}
      <motion.div
        initial={{ x: '120%', y: -20, opacity: 0, scale: 0.8 }}
        animate={{
          x: ['100%', '20%', '0%'],
          y: [-20, 10, 0],
          opacity: [0, 1, 1],
          scale: [0.8, 1, 1],
        }}
        transition={{ duration: 3.5, ease: 'easeInOut' }}
        className="absolute right-1/2 translate-x-full flex items-center gap-2"
      >
        <div className="relative">
          <svg width="65" height="50" viewBox="0 0 100 80" fill="none" className="drop-shadow-md -scale-x-100">
            <motion.path
              d="M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z"
              fill="#ffffff"
              animate={{ d: [
                "M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z",
                "M50 40 C35 30, 20 40, 10 50 C20 48, 32 45, 45 42 Z",
                "M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z"
              ] }}
              transition={{ repeat: Infinity, duration: 0.5, ease: "easeInOut" }}
            />
            <path d="M40 40 C55 40, 75 35, 85 40 C95 45, 90 55, 75 55 C60 55, 45 50, 40 40 Z" fill="#fdfbf7" />
            <path d="M15 45 L0 40 L5 52 L20 48 Z" fill="#f4ece0" />
            <circle cx="82" cy="42" r="1.5" fill="#7a1b22" />
            <path d="M86 43 L94 45 L87 47 Z" fill="#d4a325" />
          </svg>

          {/* Golden Silk Ribbon Trail Right */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 2, delay: 0.5 }}
            className="absolute top-1/2 left-full w-32 h-[2px] bg-gradient-to-r from-[#d4a325] via-[#7a1b22]/40 to-transparent -translate-y-1/2 origin-left"
          />
        </div>
      </motion.div>
    </div>
  );
};
