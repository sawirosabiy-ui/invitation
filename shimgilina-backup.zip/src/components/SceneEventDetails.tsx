import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Clock, Calendar, ExternalLink } from 'lucide-react';
import { invitationData } from '../config/invitationData';

export const SceneEventDetails: React.FC = () => {
  return (
    <div className="w-full max-w-xl mx-auto px-4 py-6 select-none">
      <motion.div
        initial={{ opacity: 0, y: 25 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.9 }}
        className="relative p-6 md:p-10 rounded-3xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-2xl shadow-[#7a1b22]/15 backdrop-blur-md overflow-hidden"
      >
        <div className="text-center mb-6">
          <span className="font-serif tracking-[0.25em] text-xs uppercase text-[#7a1b22] font-semibold">
            Event Details
          </span>
          <h3 className="font-serif text-3xl font-bold text-[#7a1b22] mt-1">
            {invitationData.eventType}
          </h3>
        </div>

        <p className="font-serif italic text-center text-sm md:text-base text-[#4d1015] leading-relaxed mb-6 px-2">
          "{invitationData.message}"
        </p>

        <div className="space-y-4 border-t border-[#7a1b22]/20 pt-6">
          <div className="flex items-start gap-4">
            <div className="p-2.5 rounded-xl bg-[#7a1b22]/10 border border-[#7a1b22]/30 text-[#7a1b22]">
              <Calendar size={20} />
            </div>
            <div>
              <p className="font-sans text-[11px] tracking-wider uppercase text-[#1b4d2e] font-semibold">
                Date
              </p>
              <p className="font-serif text-lg font-bold text-[#7a1b22]">
                {invitationData.date.formatted}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-2.5 rounded-xl bg-[#7a1b22]/10 border border-[#7a1b22]/30 text-[#7a1b22]">
              <Clock size={20} />
            </div>
            <div>
              <p className="font-sans text-[11px] tracking-wider uppercase text-[#1b4d2e] font-semibold">
                Time
              </p>
              <p className="font-serif text-lg font-bold text-[#7a1b22]">
                {invitationData.time}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-2.5 rounded-xl bg-[#7a1b22]/10 border border-[#7a1b22]/30 text-[#7a1b22]">
              <MapPin size={20} />
            </div>
            <div className="flex-1">
              <p className="font-sans text-[11px] tracking-wider uppercase text-[#1b4d2e] font-semibold">
                Location
              </p>
              <p className="font-serif text-lg font-bold text-[#7a1b22]">
                {invitationData.location.name}
              </p>
              <p className="font-sans text-xs text-[#4d1015]/80 font-medium">
                {invitationData.location.address}
              </p>
            </div>
          </div>
        </div>

        {invitationData.location.mapUrl && (
          <div className="mt-8 text-center">
            <a
              href={invitationData.location.mapUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#7a1b22] text-[#f8f3e6] border border-[#e6d8be] text-xs font-sans tracking-widest uppercase font-semibold hover:bg-[#9e222d] transition-all duration-300 shadow-md"
            >
              <MapPin size={14} />
              <span>Get Directions</span>
              <ExternalLink size={12} />
            </a>
          </div>
        )}
      </motion.div>
    </div>
  );
};
