import React from 'react';
import { motion } from 'framer-motion';
import { EnvelopeGatefold } from './EnvelopeGatefold';

interface SceneOpeningProps {
  onOpen: () => void;
}

export const SceneOpening: React.FC<SceneOpeningProps> = ({ onOpen }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.8 } }}
      className="w-full"
    >
      <EnvelopeGatefold onOpen={onOpen} />
    </motion.div>
  );
};
