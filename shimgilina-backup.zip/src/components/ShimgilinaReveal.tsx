import React from 'react';
import { motion } from 'framer-motion';
import { invitationData } from '../config/invitationData';

export const ShimgilinaReveal: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 1.1 }}
      className="py-8 my-6 text-center border-y-2 border-[#7a1b22]/20 max-w-xl mx-auto px-4"
    >
      <span className="font-serif text-xs uppercase tracking-[0.3em] text-[#1b4d2e] font-semibold block mb-2">
        The Occasion
      </span>
      <h2 className="font-serif text-4xl md:text-6xl font-bold tracking-widest text-[#7a1b22] drop-shadow-sm">
        {invitationData.eventType.toUpperCase()}
      </h2>
      <p className="font-serif italic text-base md:text-lg text-[#7a1b22]/90 mt-2 font-medium">
        "{invitationData.subtitle}"
      </p>
    </motion.div>
  );
};
