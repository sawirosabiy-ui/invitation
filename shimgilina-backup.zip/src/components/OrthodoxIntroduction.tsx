import React from 'react';
import { motion } from 'framer-motion';
import { OrthodoxCross } from './OrthodoxCross';
import { invitationData } from '../config/invitationData';

export const OrthodoxIntroduction: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 1 }}
      className="flex flex-col items-center text-center my-6 max-w-lg mx-auto px-4 select-none"
    >
      {/* Orthodox Cross Ornament */}
      <div className="p-3 rounded-full bg-[#7a1b22]/10 border border-[#7a1b22]/30 shadow-sm mb-3">
        <OrthodoxCross size={32} className="text-[#7a1b22]" />
      </div>

      {/* Ge'ez Trinitarian Invocation */}
      <p className="font-serif font-bold text-lg md:text-xl text-[#7a1b22] tracking-wide mb-1">
        {invitationData.trinityBlessing}
      </p>

      {/* English Trinitarian Invocation */}
      <h3 className="font-['Alex_Brush',_cursive] text-2xl md:text-3xl text-[#7a1b22] leading-relaxed my-1">
        "{invitationData.trinityEnglish}"
      </h3>

      {/* Gold Flourish Line */}
      <div className="flex items-center gap-3 my-3">
        <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#d4a325]" />
        <span className="text-[#d4a325] text-xs">✦ ☦ ✦</span>
        <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#d4a325]" />
      </div>
    </motion.div>
  );
};
