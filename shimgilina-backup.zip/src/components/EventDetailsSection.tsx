import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, MapPin } from 'lucide-react';
import { invitationData } from '../config/invitationData';

export const EventDetailsSection: React.FC = () => {
  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-8 select-none">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.9 }}
        className="text-center mb-8"
      >
        <span className="font-serif text-xs uppercase tracking-[0.3em] text-[#1b4d2e] font-semibold block mb-1">
          Schedule of Events
        </span>
        <h3 className="font-serif text-3xl font-bold text-[#7a1b22]">
          Event Details
        </h3>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Ceremony Card */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="relative p-6 rounded-3xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-xl"
        >
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-[#7a1b22]/20">
            <span className="text-base">☦</span>
            <h4 className="font-serif text-xl font-bold text-[#7a1b22]">
              {invitationData.ceremony.title}
            </h4>
          </div>

          <div className="space-y-3 font-serif">
            <div className="flex items-start gap-3">
              <Calendar size={18} className="text-[#7a1b22] mt-0.5" />
              <div>
                <p className="text-xs uppercase font-sans text-[#1b4d2e] font-semibold">Date</p>
                <p className="text-base font-bold text-[#4d1015]">{invitationData.ceremony.date}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Clock size={18} className="text-[#7a1b22] mt-0.5" />
              <div>
                <p className="text-xs uppercase font-sans text-[#1b4d2e] font-semibold">Time</p>
                <p className="text-base font-bold text-[#4d1015]">{invitationData.ceremony.time}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <MapPin size={18} className="text-[#7a1b22] mt-0.5" />
              <div>
                <p className="text-xs uppercase font-sans text-[#1b4d2e] font-semibold">Venue</p>
                <p className="text-base font-bold text-[#4d1015]">{invitationData.ceremony.venue}</p>
                <p className="text-xs font-sans text-[#4d1015]/70">{invitationData.ceremony.address}</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Reception Card */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative p-6 rounded-3xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-xl"
        >
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-[#7a1b22]/20">
            <span className="text-base">🥂</span>
            <h4 className="font-serif text-xl font-bold text-[#7a1b22]">
              {invitationData.reception.title}
            </h4>
          </div>

          <div className="space-y-3 font-serif">
            <div className="flex items-start gap-3">
              <Calendar size={18} className="text-[#7a1b22] mt-0.5" />
              <div>
                <p className="text-xs uppercase font-sans text-[#1b4d2e] font-semibold">Date</p>
                <p className="text-base font-bold text-[#4d1015]">{invitationData.reception.date}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Clock size={18} className="text-[#7a1b22] mt-0.5" />
              <div>
                <p className="text-xs uppercase font-sans text-[#1b4d2e] font-semibold">Time</p>
                <p className="text-base font-bold text-[#4d1015]">{invitationData.reception.time}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <MapPin size={18} className="text-[#7a1b22] mt-0.5" />
              <div>
                <p className="text-xs uppercase font-sans text-[#1b4d2e] font-semibold">Venue</p>
                <p className="text-base font-bold text-[#4d1015]">{invitationData.reception.venue}</p>
                <p className="text-xs font-sans text-[#4d1015]/70">{invitationData.reception.address}</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
