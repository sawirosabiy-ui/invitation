import React from 'react';
import { motion } from 'framer-motion';
import { OrthodoxCross } from './OrthodoxCross';
import { invitationData } from '../config/invitationData';

interface EnvelopeGatefoldProps {
  onOpen: () => void;
}

export const EnvelopeGatefold: React.FC<EnvelopeGatefoldProps> = ({ onOpen }) => {
  return (
    <div className="relative z-20 flex flex-col items-center justify-center min-h-screen px-4 py-8 overflow-hidden select-none">
      {/* Flying White Doves Header in Scene 01 */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2 }}
        className="relative z-30 flex items-center justify-center gap-6 mb-6"
      >
        {/* Left Flying Dove */}
        <motion.div
          animate={{ y: [0, -8, 0], x: [0, 5, 0] }}
          transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
        >
          <svg width="60" height="45" viewBox="0 0 100 80" fill="none" className="drop-shadow-lg">
            <motion.path
              d="M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z"
              fill="#ffffff"
              animate={{ d: [
                "M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z",
                "M50 40 C35 30, 20 40, 10 50 C20 48, 32 45, 45 42 Z",
                "M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z"
              ] }}
              transition={{ repeat: Infinity, duration: 0.6, ease: "easeInOut" }}
            />
            <path d="M40 40 C55 40, 75 35, 85 40 C95 45, 90 55, 75 55 C60 55, 45 50, 40 40 Z" fill="#fdfbf7" />
            <path d="M15 45 L0 40 L5 52 L20 48 Z" fill="#f4ece0" />
            <circle cx="82" cy="42" r="1.5" fill="#7a1b22" />
            <path d="M86 43 L94 45 L87 47 Z" fill="#d4a325" />
          </svg>
        </motion.div>

        {/* Center Cross Ornament */}
        <div className="p-2 rounded-full bg-[#7a1b22]/10 border border-[#7a1b22]/30 shadow-md backdrop-blur-sm">
          <OrthodoxCross size={24} className="text-[#7a1b22]" />
        </div>

        {/* Right Flying Dove */}
        <motion.div
          animate={{ y: [0, -8, 0], x: [0, -5, 0] }}
          transition={{ repeat: Infinity, duration: 4.2, ease: "easeInOut", delay: 0.3 }}
        >
          <svg width="60" height="45" viewBox="0 0 100 80" fill="none" className="drop-shadow-lg -scale-x-100">
            <motion.path
              d="M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z"
              fill="#ffffff"
              animate={{ d: [
                "M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z",
                "M50 40 C35 30, 20 40, 10 50 C20 48, 32 45, 45 42 Z",
                "M50 40 C30 10, 10 15, 0 30 C15 35, 30 38, 45 42 Z"
              ] }}
              transition={{ repeat: Infinity, duration: 0.6, ease: "easeInOut" }}
            />
            <path d="M40 40 C55 40, 75 35, 85 40 C95 45, 90 55, 75 55 C60 55, 45 50, 40 40 Z" fill="#fdfbf7" />
            <path d="M15 45 L0 40 L5 52 L20 48 Z" fill="#f4ece0" />
            <circle cx="82" cy="42" r="1.5" fill="#7a1b22" />
            <path d="M86 43 L94 45 L87 47 Z" fill="#d4a325" />
          </svg>
        </motion.div>
      </motion.div>

      {/* Outer Envelope Wrapper Frame */}
      <div className="relative w-full max-w-lg aspect-[3/4] md:aspect-[4/5] rounded-3xl shadow-[0_20px_50px_rgba(77,16,21,0.3)] border-2 border-[#7a1b22]/40 overflow-hidden bg-[#fbf7ee]">
        
        {/* Left Scalloped Gatefold Door */}
        <motion.div
          exit={{ x: '-100%', opacity: 0, transition: { duration: 1.2, ease: [0.77, 0, 0.175, 1] } }}
          className="absolute top-0 bottom-0 left-0 w-1/2 bg-[#f8f2e4] border-r border-[#7a1b22]/20 z-10 flex flex-col justify-between p-6 shadow-xl"
        >
          {/* Left Rose Vines */}
          <div className="flex flex-col items-start space-y-8 opacity-85">
            <svg width="70" height="140" viewBox="0 0 70 140" fill="none">
              <path d="M10 0 Q 35 70 15 140" stroke="#7a1b22" strokeWidth="2" fill="none" />
              <circle cx="28" cy="35" r="7" fill="#9e222d" />
              <circle cx="15" cy="80" r="6" fill="#7a1b22" />
              <path d="M28 35 Q 40 30 45 38" stroke="#2d6a4f" strokeWidth="2" />
            </svg>
          </div>
          <div className="flex flex-col items-start space-y-8 opacity-85">
            <svg width="70" height="140" viewBox="0 0 70 140" fill="none">
              <path d="M18 0 Q 8 70 30 140" stroke="#7a1b22" strokeWidth="2" fill="none" />
              <circle cx="12" cy="45" r="7" fill="#9e222d" />
              <circle cx="26" cy="100" r="6" fill="#7a1b22" />
            </svg>
          </div>
        </motion.div>

        {/* Right Scalloped Gatefold Door */}
        <motion.div
          exit={{ x: '100%', opacity: 0, transition: { duration: 1.2, ease: [0.77, 0, 0.175, 1] } }}
          className="absolute top-0 bottom-0 right-0 w-1/2 bg-[#f8f2e4] border-l border-[#7a1b22]/20 z-10 flex flex-col justify-between p-6 shadow-xl"
        >
          {/* Right Rose Vines */}
          <div className="flex flex-col items-end space-y-8 opacity-85">
            <svg width="70" height="140" viewBox="0 0 70 140" fill="none">
              <path d="M60 0 Q 35 70 55 140" stroke="#7a1b22" strokeWidth="2" fill="none" />
              <circle cx="42" cy="35" r="7" fill="#9e222d" />
              <circle cx="55" cy="80" r="6" fill="#7a1b22" />
            </svg>
          </div>
          <div className="flex flex-col items-end space-y-8 opacity-85">
            <svg width="70" height="140" viewBox="0 0 70 140" fill="none">
              <path d="M52 0 Q 62 70 40 140" stroke="#7a1b22" strokeWidth="2" fill="none" />
              <circle cx="58" cy="45" r="7" fill="#9e222d" />
              <circle cx="44" cy="100" r="6" fill="#7a1b22" />
            </svg>
          </div>
        </motion.div>

        {/* Center White Silk Ribbon Bar */}
        <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 h-16 bg-white/70 backdrop-blur-sm border-y border-[#7a1b22]/25 shadow-md z-20 flex items-center justify-center pointer-events-none" />

        {/* Center Wax Seal Interactive Button */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-30 flex flex-col items-center">
          <button
            onClick={onOpen}
            className="group relative flex items-center justify-center w-26 h-26 md:w-30 md:h-30 rounded-full bg-gradient-to-br from-[#9e222d] via-[#7a1b22] to-[#4d1015] border-4 border-[#e6d8be] shadow-[0_10px_30px_rgba(77,16,21,0.6)] hover:scale-105 active:scale-95 transition-transform duration-300 cursor-pointer"
          >
            <div className="absolute inset-1 rounded-full border border-dashed border-[#f8f3e6]/50 pointer-events-none" />

            <div className="flex flex-col items-center justify-center text-[#f8f3e6] group-hover:rotate-6 transition-transform">
              <OrthodoxCross size={38} className="text-[#f8f3e6] drop-shadow-md" />
              <span className="font-serif text-[10px] uppercase tracking-widest text-[#f8f3e6] mt-0.5 font-bold">
                OPEN
              </span>
            </div>
          </button>

          <p className="font-serif italic text-xs md:text-sm text-[#7a1b22] font-semibold mt-4 tracking-wider animate-pulse">
            Tap Wax Seal to Open
          </p>
        </div>

        {/* Outer Envelope Typography Preview */}
        <div className="absolute top-8 left-0 right-0 text-center z-20 pointer-events-none">
          <p className="font-serif text-xs uppercase tracking-[0.25em] text-[#7a1b22] font-semibold">
            {invitationData.openingText}
          </p>
          <h1 className="font-serif text-3xl md:text-4xl font-bold text-[#7a1b22] tracking-wide mt-1">
            {invitationData.title}
          </h1>
        </div>
      </div>
    </div>
  );
};
