import React from 'react';

export const GoldenCrowns: React.FC<{ className?: string }> = ({ className = "my-3" }) => {
  return (
    <div className={`flex items-center justify-center gap-4 ${className}`}>
      {/* Left Golden Orthodox Crown */}
      <svg width="44" height="34" viewBox="0 0 60 45" fill="none" className="drop-shadow-md">
        <path
          d="M5 38 H55 L50 18 L38 28 L30 8 L22 28 L10 18 Z"
          fill="url(#goldCrownGrad)"
          stroke="#92611a"
          strokeWidth="1.5"
        />
        <rect x="5" y="34" width="50" height="6" rx="2" fill="#d4a325" stroke="#794d1c" />
        <circle cx="30" cy="8" r="3" fill="#b52b36" />
        <circle cx="10" cy="18" r="2.5" fill="#7a1b22" />
        <circle cx="50" cy="18" r="2.5" fill="#7a1b22" />
        <circle cx="22" cy="28" r="2" fill="#2d6a4f" />
        <circle cx="38" cy="28" r="2" fill="#2d6a4f" />
        <defs>
          <linearGradient id="goldCrownGrad" x1="0" y1="0" x2="60" y2="45" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#f3e5ab" />
            <stop offset="50%" stopColor="#d4a325" />
            <stop offset="100%" stopColor="#aa8c4a" />
          </linearGradient>
        </defs>
      </svg>

      {/* Right Golden Orthodox Crown */}
      <svg width="44" height="34" viewBox="0 0 60 45" fill="none" className="drop-shadow-md">
        <path
          d="M5 38 H55 L50 18 L38 28 L30 8 L22 28 L10 18 Z"
          fill="url(#goldCrownGrad)"
          stroke="#92611a"
          strokeWidth="1.5"
        />
        <rect x="5" y="34" width="50" height="6" rx="2" fill="#d4a325" stroke="#794d1c" />
        <circle cx="30" cy="8" r="3" fill="#b52b36" />
        <circle cx="10" cy="18" r="2.5" fill="#7a1b22" />
        <circle cx="50" cy="18" r="2.5" fill="#7a1b22" />
        <circle cx="22" cy="28" r="2" fill="#2d6a4f" />
        <circle cx="38" cy="28" r="2" fill="#2d6a4f" />
      </svg>
    </div>
  );
};
