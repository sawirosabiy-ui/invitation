import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import confetti from 'canvas-confetti';
import { Calendar } from 'lucide-react';
import { invitationData } from '../config/invitationData';

export const SceneDatePayoff: React.FC = () => {
  useEffect(() => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#7a1b22', '#1b4d2e', '#d4af37', '#b52b36'],
        ticks: 200,
        gravity: 0.8,
        scalar: 0.9,
      });
    } catch {
      // Fallback
    }
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
      className="w-full max-w-xl mx-auto px-4 py-8 text-center select-none"
    >
      <div className="relative p-8 md:p-12 rounded-3xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-2xl shadow-[#7a1b22]/15 backdrop-blur-xl overflow-hidden">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Calendar size={20} className="text-[#7a1b22]" />
          <span className="font-serif tracking-[0.3em] text-xs uppercase text-[#7a1b22] font-semibold">
            The Date
          </span>
        </div>

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="font-sans text-xs md:text-sm font-semibold tracking-[0.35em] uppercase text-[#1b4d2e] mb-2"
        >
          {invitationData.date.dayOfWeek}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="my-3"
        >
          <h2 className="font-serif text-5xl md:text-7xl font-bold tracking-tight text-[#7a1b22]">
            {invitationData.date.month} {invitationData.date.day}
          </h2>
          <p className="font-serif text-3xl md:text-4xl font-semibold text-[#1b4d2e] mt-1">
            {invitationData.date.year}
          </p>
        </motion.div>

        <div className="w-24 h-[2px] bg-[#7a1b22]/30 mx-auto my-6" />

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="font-serif italic text-base md:text-lg text-[#7a1b22] font-medium"
        >
          Time: {invitationData.time}
        </motion.p>
      </div>
    </motion.div>
  );
};
