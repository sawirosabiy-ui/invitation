import React from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';
import { invitationData } from '../config/invitationData';

export const MemoryStorySection: React.FC = () => {
  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-8 select-none">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="text-center mb-8"
      >
        <div className="inline-flex items-center justify-center p-2 rounded-full bg-[#7a1b22]/10 border border-[#7a1b22]/20 mb-3">
          <Heart size={16} className="text-[#7a1b22]" />
        </div>
        <span className="font-serif text-xs uppercase tracking-[0.3em] text-[#1b4d2e] font-semibold block mb-1">
          Our Story &amp; Memories
        </span>
        <h3 className="font-serif italic text-2xl md:text-3xl font-bold text-[#7a1b22] max-w-lg mx-auto leading-relaxed">
          "{invitationData.memoryStory.quote}"
        </h3>
      </motion.div>

      {/* Editorial Memories Layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6">
        {invitationData.memoryStory.memories.map((item, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: idx * 0.2 }}
            className="group relative rounded-2xl overflow-hidden border-2 border-[#7a1b22]/25 shadow-xl bg-[#fdfbf7]"
          >
            <div className="relative aspect-[4/3] overflow-hidden">
              <img
                src={item.image}
                alt={item.caption}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#7a1b22]/60 via-transparent to-transparent" />
            </div>
            <div className="p-4 text-center bg-[#fdfbf7]">
              <p className="font-serif italic text-base font-semibold text-[#7a1b22]">
                {item.caption}
              </p>
            </div>
          </motion.div>
        ))}
      </div>

      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, delay: 0.4 }}
        className="font-serif text-sm md:text-base italic text-center text-[#4d1015]/80 max-w-lg mx-auto leading-relaxed mt-4"
      >
        {invitationData.memoryStory.storyParagraph}
      </motion.p>
    </div>
  );
};
