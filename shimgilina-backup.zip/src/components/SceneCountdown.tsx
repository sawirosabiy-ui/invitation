import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Clock } from 'lucide-react';
import { invitationData } from '../config/invitationData';
import { calculateTimeLeft, CountdownTimeLeft } from '../utils/countdown';

export const SceneCountdown: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState<CountdownTimeLeft>(() =>
    calculateTimeLeft(invitationData.eventDateTime)
  );

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft(invitationData.eventDateTime));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full max-w-xl mx-auto px-4 py-6 text-center select-none">
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="mb-6"
      >
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#7a1b22]/10 border border-[#7a1b22]/30 text-[#7a1b22] text-xs font-sans tracking-widest uppercase mb-2 font-semibold">
          <Clock size={13} className="text-[#7a1b22]" />
          <span>Real-Time Countdown</span>
        </div>
        <h3 className="font-serif text-2xl md:text-3xl font-bold tracking-wide text-[#7a1b22]">
          The Countdown Begins
        </h3>
      </motion.div>

      {timeLeft.isCompleted ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="p-6 rounded-2xl bg-[#fdfbf7] border border-[#7a1b22]/30 text-center shadow-lg"
        >
          <p className="font-serif text-2xl text-[#7a1b22] font-semibold">
            ✦ The Shimgilina Celebration Has Arrived ✦
          </p>
        </motion.div>
      ) : (
        <div className="grid grid-cols-4 gap-3 md:gap-4 max-w-md mx-auto">
          {/* Days */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="flex flex-col items-center p-3 md:p-4 rounded-xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-md"
          >
            <span className="font-serif text-3xl md:text-5xl font-bold text-[#7a1b22]">
              {String(timeLeft.days).padStart(2, '0')}
            </span>
            <span className="font-sans text-[10px] md:text-xs tracking-widest uppercase text-[#1b4d2e] font-semibold mt-1">
              Days
            </span>
          </motion.div>

          {/* Hours */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col items-center p-3 md:p-4 rounded-xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-md"
          >
            <span className="font-serif text-3xl md:text-5xl font-bold text-[#7a1b22]">
              {String(timeLeft.hours).padStart(2, '0')}
            </span>
            <span className="font-sans text-[10px] md:text-xs tracking-widest uppercase text-[#1b4d2e] font-semibold mt-1">
              Hours
            </span>
          </motion.div>

          {/* Minutes */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col items-center p-3 md:p-4 rounded-xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-md"
          >
            <span className="font-serif text-3xl md:text-5xl font-bold text-[#7a1b22]">
              {String(timeLeft.minutes).padStart(2, '0')}
            </span>
            <span className="font-sans text-[10px] md:text-xs tracking-widest uppercase text-[#1b4d2e] font-semibold mt-1">
              Mins
            </span>
          </motion.div>

          {/* Seconds */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col items-center p-3 md:p-4 rounded-xl bg-[#fdfbf7] border-2 border-[#7a1b22]/30 shadow-md"
          >
            <span className="font-serif text-3xl md:text-5xl font-bold text-[#7a1b22]">
              {String(timeLeft.seconds).padStart(2, '0')}
            </span>
            <span className="font-sans text-[10px] md:text-xs tracking-widest uppercase text-[#1b4d2e] font-semibold mt-1">
              Secs
            </span>
          </motion.div>
        </div>
      )}
    </div>
  );
};
