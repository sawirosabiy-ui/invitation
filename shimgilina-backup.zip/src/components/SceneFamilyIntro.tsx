import React from 'react';
import { motion } from 'framer-motion';
import { OrthodoxCross } from './OrthodoxCross';
import { GoldenCrowns } from './GoldenCrowns';
import { invitationData } from '../config/invitationData';

export const SceneFamilyIntro: React.FC = () => {
  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-6 text-center select-none">
      {/* Top White Doves & Orthodox Cross Emblem */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.9 }}
        className="flex flex-col items-center mb-6"
      >
        <div className="flex items-center justify-center gap-4 mb-3">
          {/* Left Dove Vector */}
          <svg width="45" height="35" viewBox="0 0 50 40" fill="none" className="text-[#e8dcc4]">
            <path d="M45 20 C35 5, 20 5, 10 15 C5 20, 0 30, 5 35 C15 35, 25 25, 35 25 Z" fill="currentColor" />
            <circle cx="12" cy="18" r="1.5" fill="#7a1b22" />
          </svg>

          <div className="p-2 rounded-full bg-[#7a1b22]/10 border border-[#7a1b22]/30">
            <OrthodoxCross size={26} className="text-[#7a1b22]" />
          </div>

          {/* Right Dove Vector */}
          <svg width="45" height="35" viewBox="0 0 50 40" fill="none" className="text-[#e8dcc4] -scale-x-100">
            <path d="M45 20 C35 5, 20 5, 10 15 C5 20, 0 30, 5 35 C15 35, 25 25, 35 25 Z" fill="currentColor" />
            <circle cx="12" cy="18" r="1.5" fill="#7a1b22" />
          </svg>
        </div>

        {/* Ceremonial Header Phrase */}
        <p className="font-serif italic text-lg md:text-xl text-[#7a1b22] max-w-lg leading-relaxed font-semibold">
          "{invitationData.blessingHeader}"
        </p>
      </motion.div>

      {/* Main Parchment Invitation Card */}
      <motion.div
        initial={{ opacity: 0, y: 25 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1, delay: 0.2 }}
        className="relative p-8 md:p-12 rounded-3xl bg-[#fdfbf7]/90 border-2 border-[#7a1b22]/25 shadow-2xl shadow-[#7a1b22]/10 backdrop-blur-md mb-8 overflow-hidden"
      >
        {/* Subtle Decorative Rose Corners */}
        <div className="absolute top-2 left-2 text-[#7a1b22]/40 text-sm">🌹</div>
        <div className="absolute top-2 right-2 text-[#7a1b22]/40 text-sm">🌹</div>
        <div className="absolute bottom-2 left-2 text-[#7a1b22]/40 text-sm">🌹</div>
        <div className="absolute bottom-2 right-2 text-[#7a1b22]/40 text-sm">🌹</div>

        {/* Twin Golden Crowns from reference video */}
        <GoldenCrowns className="mb-4" />

        {/* Ge'ez & English Occasion Title */}
        <p className="font-serif font-bold text-sm md:text-base text-[#7a1b22] tracking-widest uppercase mb-1">
          {invitationData.geezOccasion} • {invitationData.eventType}
        </p>

        <p className="font-serif italic text-sm text-[#4d1015]/80 mb-6">
          Together with their families
        </p>

        {/* Couple Calligraphy Names in Forest Green / Crimson */}
        <div className="py-2 flex flex-col items-center gap-1">
          <span className="font-['Alex_Brush',_cursive] text-4xl md:text-6xl text-[#1b4d2e] tracking-wide">
            {invitationData.groom.name}
          </span>
          <span className="font-serif italic text-xl text-[#7a1b22] my-1">&amp;</span>
          <span className="font-['Alex_Brush',_cursive] text-4xl md:text-6xl text-[#1b4d2e] tracking-wide">
            {invitationData.bride.name}
          </span>
        </div>

        {/* Family Parents Line */}
        <p className="font-sans text-xs tracking-widest uppercase text-[#7a1b22] font-semibold mt-6 pt-4 border-t border-[#7a1b22]/15">
          {invitationData.groom.family} • {invitationData.bride.family}
        </p>
      </motion.div>
    </div>
  );
};
