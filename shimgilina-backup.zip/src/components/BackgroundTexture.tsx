import React from 'react';

export const BackgroundTexture: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden bg-[#f4ece0]">
      {/* Soft Vignette & Paper Grain Layer */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(253,251,247,0.9)_0%,_rgba(242,233,216,0.95)_70%,_rgba(224,210,186,1)_100%)]" />

      {/* Classical Marble Column Left Side (Vector SVG styling) */}
      <div className="absolute top-0 bottom-0 left-0 w-16 md:w-28 opacity-25 flex flex-col items-center">
        <svg className="w-full h-full" viewBox="0 0 100 800" preserveAspectRatio="none">
          {/* Capital */}
          <rect x="10" y="10" width="80" height="20" rx="4" fill="#64171d" />
          <rect x="20" y="30" width="60" height="15" fill="#7a1b22" />
          {/* Fluted Column Shaft */}
          <rect x="25" y="45" width="50" height="710" fill="#7a1b22" opacity="0.15" />
          <line x1="35" y1="45" x2="35" y2="755" stroke="#7a1b22" strokeWidth="3" opacity="0.3" />
          <line x1="50" y1="45" x2="50" y2="755" stroke="#7a1b22" strokeWidth="4" opacity="0.35" />
          <line x1="65" y1="45" x2="65" y2="755" stroke="#7a1b22" strokeWidth="3" opacity="0.3" />
          {/* Base */}
          <rect x="15" y="755" width="70" height="35" rx="4" fill="#64171d" />
        </svg>
      </div>

      {/* Classical Marble Column Right Side */}
      <div className="absolute top-0 bottom-0 right-0 w-16 md:w-28 opacity-25 flex flex-col items-center">
        <svg className="w-full h-full" viewBox="0 0 100 800" preserveAspectRatio="none">
          <rect x="10" y="10" width="80" height="20" rx="4" fill="#64171d" />
          <rect x="20" y="30" width="60" height="15" fill="#7a1b22" />
          <rect x="25" y="45" width="50" height="710" fill="#7a1b22" opacity="0.15" />
          <line x1="35" y1="45" x2="35" y2="755" stroke="#7a1b22" strokeWidth="3" opacity="0.3" />
          <line x1="50" y1="45" x2="50" y2="755" stroke="#7a1b22" strokeWidth="4" opacity="0.35" />
          <line x1="65" y1="45" x2="65" y2="755" stroke="#7a1b22" strokeWidth="3" opacity="0.3" />
          <rect x="15" y="755" width="70" height="35" rx="4" fill="#64171d" />
        </svg>
      </div>

      {/* Subtle Fine Noise Paper Grain Overlay */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.04] mix-blend-multiply">
        <filter id="paperNoise">
          <feTurbulence type="fractalNoise" baseFrequency="0.6" numOctaves="3" stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#paperNoise)" />
      </svg>
    </div>
  );
};
