/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        parchment: {
          50: '#fdfbf7',
          100: '#f8f3e6',
          200: '#f2e9d8',
          300: '#e6d8be',
          400: '#d7c29e',
          500: '#c5aa7d',
        },
        crimson: {
          50: '#fcf3f4',
          100: '#f9e6e8',
          300: '#e59da3',
          500: '#b52b36',
          600: '#9e222d',
          700: '#7a1b22',
          800: '#64171d',
          900: '#4d1015',
        },
        forest: {
          DEFAULT: '#1b4d2e',
          light: '#2d6a4f',
          dark: '#133922',
        },
        gold: {
          50: '#fefcf3',
          100: '#fbf5d9',
          200: '#f5e7a9',
          300: '#edd272',
          400: '#e3b942',
          500: '#d4a325',
          600: '#b7831c',
          700: '#92611a',
          800: '#794d1c',
        }
      },
      fontFamily: {
        serif: ['Cormorant Garamond', 'Cinzel', 'Playfair Display', 'Georgia', 'serif'],
        sans: ['Plus Jakarta Sans', 'Inter', 'sans-serif'],
      },
      animation: {
        'shimmer': 'shimmer 2.5s infinite linear',
        'float': 'float 6s ease-in-out infinite',
        'petal-fall': 'petalFall 10s linear infinite',
      },
      keyframes: {
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        petalFall: {
          '0%': { transform: 'translateY(-10%) rotate(0deg)', opacity: '0.8' },
          '100%': { transform: 'translateY(110vh) rotate(360deg)', opacity: '0' },
        }
      }
    },
  },
  plugins: [],
}
